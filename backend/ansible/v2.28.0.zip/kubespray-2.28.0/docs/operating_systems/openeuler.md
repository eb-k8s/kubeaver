# OpenEuler

[OpenEuler](https://www.openeuler.org/en/) Linux is supported with docker and containerd runtimes.

**Note:** that OpenEuler Linux is not currently covered in kubespray CI and
support for it is currently considered experimental.

At present, only `openEuler 22.03 LTS` has been adapted, which can support the deployment of aarch64 and x86_64 platforms.

There are no special considerations for using OpenEuler Linux as the target OS
for Kubespray deployments.
